package lzhs.com.library.mvp;

/**
 * <br/>
 * 作者：LZHS<br/>
 * 时间： 2017/10/23 23:14<br/>
 * 邮箱：1050629507@qq.com
 */
public abstract class IModel{

     protected abstract void onCreate();
    protected abstract  void onDestroy();

}
