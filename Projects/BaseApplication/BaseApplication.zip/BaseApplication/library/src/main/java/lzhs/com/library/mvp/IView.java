package lzhs.com.library.mvp;

/**
 * 所有MVP 中View接口都将继承与该接口<br/>
 * 作者：LZHS<br/>
 * 时间： 2017/5/8 0008 11:15<br/>
 * 邮箱：1050629507@qq.com
 */

public interface IView {



}
