package lzhs.com.library.utils;

/**
 * <br/>
 * 作者：LZHS<br/>
 * 时间： 2017/10/23 23:42<br/>
 * 邮箱：1050629507@qq.com
 */
public class ActivityUtil {

    public final  String  TAG=getClass().getSimpleName();



}
