package lzhs.com.baseapplication.test;

import lzhs.com.library.mvp.IView;

/**
 * <br/>
 * 作者：LZHS<br/>
 * 时间： 2017/10/23 23:29<br/>
 * 邮箱：1050629507@qq.com
 */
public interface TestView extends IView {



    void  setText(String content);


}
